package com.digital.crud.saladereuniao.saladereuniao;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SaladereuniaoApplicationTests {

	@Test
	void contextLoads() {
	}

}
